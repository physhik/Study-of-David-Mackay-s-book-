gset zrange [-1:-0.1]
				# gset nocontour
				# gset noparametric
gset clip one # clip out the surface
gset surface
