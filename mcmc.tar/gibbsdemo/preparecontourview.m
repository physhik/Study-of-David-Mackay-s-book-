gset contour base
gset nosurface
gset view 0,0
