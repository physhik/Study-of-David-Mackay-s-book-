preparedatawindow

gplot odata w p 5 3

unsetdata
