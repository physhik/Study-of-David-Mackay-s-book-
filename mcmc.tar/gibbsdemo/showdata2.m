preparedatawindow2

gplot odata w p 5 3

unsetdata
