				# this is very similar to gibbsplot but with the line removed

      preparecontourplot
				# was: 
				# gsplot  zz w l 1,  wlt u 1:2:3 w p 7 4, wl u 1:2:3 w p 3 3
      
      morepreparecontour
      gsplot   zz w l 1
				repreparecontour
      gsplot   wlt u 1:2:3 w p 7 4, wl u 1:2:3 w p 3 3

#	gsplot wlt u 1:2:3 w l 7 7, zz w l 1,  wlt u 1:2:3 w p 1 4, wl u 1:2:3 w p 3 3
	
