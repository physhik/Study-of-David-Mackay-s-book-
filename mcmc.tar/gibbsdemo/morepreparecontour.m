gset nosurface
gset noclip
gset autos z

