gset yrange [-0.4:3.1];
gset xrange [-5:5] ; 
gset key
