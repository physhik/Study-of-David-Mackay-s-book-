gset yrange [-0.2:4.1];
gset xrange [-5:5] ; 
gset key
