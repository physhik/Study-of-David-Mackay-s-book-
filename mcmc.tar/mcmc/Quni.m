function Q =  Quni( x , high ) 
Q = high * ones(size(x)) ;
endfunction 
