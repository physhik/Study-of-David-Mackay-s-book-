gset nokey
gset size 0.7,0.7
gset nologscale xy
gset autos xy
gset clip one
gset noyzeroaxis
gset xzeroaxis
gset title ""
# purge_tmp_files ;
	system("~/bin/cleantmpoctave") ;
