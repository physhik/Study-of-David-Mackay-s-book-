function p = phi ( x ) 
#  phi(x) is a function whose mean we want
 	p  = 0.2 *( x + 5.0 ) ; 
endfunction