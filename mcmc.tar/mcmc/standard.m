  global spacing ;
 x = [ -5: spacing :5 ]' ;
 y = [ x , pstar( x ) ] ; 
 xphi = [ x , phi(x)  ] ; 
ranges ;
