	rejranges ;
	 gplot y u 1:2 t 'P*(x)' w lines 1 1 , xQ u 1:2 t 'cQ*(x)' w l 4 4 ;
