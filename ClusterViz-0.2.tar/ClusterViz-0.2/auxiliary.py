#
#    auxiliary.py - auxiliary routines for ClusterViz package
#
#    Copyright (C) 2005 Jonas Maaskola
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
import Numeric, os, string, sys

def read_data(fileName):

    try:
        if fileName == "-":
            file = sys.stdin
        else:
            file = open(fileName,'r')
        lines = file.readlines()
        file.close()
    
        data = []
        for l in lines:
            #logger.info(str(string.split(l)))
            data.append(Numeric.array(map(float,string.split(l))))
    
        return data
    except:
        return []

def fail_if_nonexistent(path, msg = None):

    try:
        os.stat(path)
    except:
        print "%s not found. Please check path validity." % path
        if msg is not None:
            print msg
        sys.exit(2)

def read_matrix(path):
    try:
        file = open(path,'r')
        lines = file.readlines()
        file.close()
        
        matrix = Numeric.empty([len(lines), len(lines[0].split())])
        for i in range(len(lines)):
            matrix[i] = [float(x) for x in lines[i].split()]
        return matrix
    except:
        return Numeric.empty(0)
