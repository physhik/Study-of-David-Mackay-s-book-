#
#    visualkmeans.py - kmeans-clustering algorithms with visualization hooks
#
#    Copyright (C) 2003  Alexander Schliep
#    Copyright (C) 2005  Janne Grunau, Jonas Maaskola
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

import Numeric
import RandomArray
import MLab

import copy, logging, math, pstats, random, string, sys, threading
import clusterdisplay

DEBUGOUTPUT = 0

logger = logging.getLogger("Clustering")

def initLogger():
    # Organize logging.
    logger = logging.getLogger("Clustering")
    hdlr = logging.StreamHandler()
    if not DEBUGOUTPUT:
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter('%(message)s')
    else:
        logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter('Clustering %(levelname)s %(message)s')
    hdlr.setFormatter(formatter)
    logger.addHandler(hdlr)

profiling = 0
eps = 0.001


def HammingDistance (v, w):
    return Numeric.innerproduct(v,v) + Numeric.innerproduct(w,w) - 2 * Numeric.innerproduct(v,w)


def Euclidean (v, w):
    x = v-w
    return math.sqrt(Numeric.innerproduct(x,x))


def OrderedPairs (input_list):
    result = []
    for i, v in enumerate(input_list):
        for w in input_list[i+1:]:
            result.append((v,w))
    return result


def AllPairs (L, M):
    return  [(x,y) for x in L for y in M]


def Entropy (probdist):
    """Calculates the Shannon entropy in nats.
    Expects a probability distriubtion as argument."""
    probdist = [v for v in probdist if v!=0.0]

    return -Numeric.sum(probdist * Numeric.log(probdist))




class Clustering(threading.Thread):
    def __init__(self, data, display, k, dist, algorithm, redraw_event, beta = None):
        self.display = display
        self.seqs = data
        self.algorithm = algorithm
        self.beta = beta
        self.end_flag=False
        self.thread_suspend=False
        self.sleep_time=0.0
        self.thread_sleep=False
        threading.Thread.__init__(self)
        # Default values
        self.k = k
        self.distanceFunction = dist

        #threading syncronizisation
        self.abortNOW = False
        self.redraw_event = redraw_event

    
        self.nrSeqs = len(self.seqs)
        self.responbilityFunction = None

        self.sqrtof2pi = math.sqrt(2*math.pi)
        self.dimensions = len(self.seqs[0])
        self.pi = Numeric.array([1.0/self.k]*self.k)
        self.sigma = Numeric.array([[.3]*self.dimensions]*self.k)

        self.printDetails = len(self.seqs) < 1.5e2
        logger.info("Details: "+str(self.printDetails))


    def run(self):

        #wait for the display coming ready
        self.redraw_event.wait()
        self.display.updateDisplay()
        self.redraw_event.wait()
        logger.debug("Clustering started.")

        if self.algorithm == "KMeans":
            self.computeKMeans(self.k)
            if self.printDetails and not self.abortNOW:
                self.display.enableHistory(self.singleKMeans)
                prettyPrint(range(len(self.seqs)), self)
                
        elif self.algorithm == "softKMeans":
            self.computeSoftKMeans(self.k, self.computeResposibilities)
            if not self.abortNOW:
                self.display.enableHistory(self.singleSoftKMeans)
                
        elif self.algorithm == "improvedSoftKMeans":
            self.computeSoftKMeans(self.k, self.computeGaussianResposibilities)
            if not self.abortNOW:
                self.display.enableHistory(self.singleSoftKMeans)

        logger.debug("Done.")


    def minimalRadii (self):
        # initialisation and minimun for cluster 0
        radii = Numeric.array ([self.distanceFunction (self.reps[0], self.reps[1])/4]*self.dimensions)
        #logger.info("distance cluster 0 vs. cluster 1: "+str(radii))
        self.sigma[0] = radii
        self.sigma[1] = radii
        for c in xrange(2, self.k):
            radii = Numeric.array ([self.distanceFunction (self.reps[0], self.reps[c])/4]*self.dimensions)
            #logger.info("distance cluster 0 vs. cluster "+str(c) + ":" + str(radii))
            if radii[0] < self.sigma[0][0]:
                self.sigma[0] = radii
            self.sigma[c] = radii

        #find minimum
        for c in xrange(1, self.k-1):
            for b in xrange(c+1, self.k):
                radii = Numeric.array ([self.distanceFunction (self.reps[c], self.reps[b])/4]*self.dimensions)
                #logger.info("distance cluster " + str(c) + " vs. cluster " + str(b) + ": " + str(radii))
                if radii[0] < self.sigma[c][0]:
                    self.sigma[c] = radii
                if radii[0] < self.sigma[b][0]:
                    self.sigma[b] = radii


    def computeKMeans (self, k):
        self.k = k
        self.entropyMax = Entropy([(1.0/k)]*k)

        # --------- Compute an initial partition ----------
        # Here: pick k different seqs 
        initial = self.selectkDistinctSeqs(k)
        #logger.info("# Initially selected strings" + str(initial))

        self.reps = []
        self.display.clearClusters(k)
        for i in initial:
            self.reps.append(copy.copy(self.seqs[i]))
            
        logger.info("Cluster centers:")
        logger.info(str(self.reps))
        logger.info("Standard deviations:")
        for line in str(self.sigma).split("\n"): logger.info(line)

        # ------- compute minimal radii -------
        self.minimalRadii()
        logger.info("Standard deviations:")
        for line in str(self.sigma).split("\n"): logger.info(line)

        self.clustercenters = [[]] * k
        self.data = [None] * self.nrSeqs

        # --------- Iterate -------------------------------
        goOn = 1
        while goOn and not self.abortNOW:
            self.redraw_event.wait()
            goOn = self.singleKMeans (k)
            

    def singleKMeans (self, k, reps=None, radius=None, waittime=None):

        if reps != None:
            self.reps = reps
            self.sigma = radius
            self.clustercenters = [[]] * k
            self.data = [None] * self.nrSeqs
            
        # -------- Assign sequences to clusters -------
        assignment_changed = 0
        
        for c in xrange(k):
            self.clustercenters[c] = []
            
        for i in xrange(self.nrSeqs):
            (c, entropy) = self.findClosest(i)

            if self.data[i] != c:
                assignment_changed = 1
            #hook function for updating cluster assignment of data point i
            self.display.changeAssignment(i, c, entropy)

            self.data[i] = c
            self.clustercenters[c].append(i)
            
        self.display.regenData = True
        logger.debug("Data points per clusters: " + str(self.clustercenters))
        self.redraw_event.wait(waittime)
        #ugly check to abort computation
        if self.abortNOW: return

        # -------- Display clusters before updating ---
        for c in xrange(k):
            #hook function for cluster centroid display
            self.display.updateCluster(c, self.reps[c], self.sigma[c])
            self.redraw_event.wait(waittime)
            #ugly check to abort computation
            if self.abortNOW: return 0

        # if the update only the display we are finished
        if reps != None:
            return 0

        # -------- recompute reps -------
        for c in xrange(k):
          
            self.redraw_event.wait()
            #ugly check to abort computation
            if self.abortNOW: return 0

            if len(self.clustercenters[c]) > 0:
                new_rep = copy.copy(self.seqs[self.clustercenters[c][0]])
                for i in xrange(1,len(self.clustercenters[c])):
                    new_rep += self.seqs[self.clustercenters[c][i]]

                new_rep = new_rep * (1.0 / len(self.clustercenters[c]))
                self.reps[c] = new_rep

        # -------- compute minimal radii -------
        self.minimalRadii()
        logger.info("Standard deviations:")
        for line in (str(self.sigma)).split("\n"): logger.info(line)
        

        return assignment_changed
                

    def computeSoftKMeans(self, k, responbilityFunction):
        self.k = k
        self.entropyMax = Entropy([(1.0/k)]*k)
        
        self.responbilityFunction = responbilityFunction

        # --------- Compute an initial partition ----------
        # Here: pick k different seqs 
        initial = self.selectkDistinctSeqs(k)
        #logger.info("# Initially selected strings " + str(initial))

        self.reps = []
        self.display.clearClusters(k)
        for i in initial:
            self.reps.append(copy.copy(self.seqs[i]))

        #logger.info("reps" + str(self.reps))
        self.data = [Numeric.array([0.0]*k)] * self.nrSeqs

        # --------- Iterate -------------------------------
        goOn = 1
        while goOn and not self.abortNOW:
            self.redraw_event.wait()
            goOn = self.singleSoftKMeans(k)


    def singleSoftKMeans(self, k, reps=None, sigma=None, waittime=None):

            if reps != None:
              self.reps = reps
              self.sigma = sigma
              self.data = [Numeric.array([0.0]*k)] * self.nrSeqs
            
            # -------- Assign sequences to clusters -------
            assignment_changed = 0

            self.clustercenters = Numeric.array([0.0] * k)

            for i in xrange(self.nrSeqs):
                (respons, c, entropy) = self.responbilityFunction(i)

                if self.distanceFunction(self.data[i], respons) > eps:
                    assignment_changed = 1
                #hook function for updating cluster assignment of data point i
                self.display.changeAssignment(i, c, entropy)

                self.data[i]         = respons
                self.clustercenters += respons
                
            self.display.regenData = True
            logger.debug("Data points per clusters: " + str(self.clustercenters))
            self.redraw_event.wait(waittime)
            #ugly check to abort computation
            if self.abortNOW: return 0


            # -------- Display clusters before updating ---
            for c in xrange(k):
                #hook function for cluster centroid display
                self.display.updateCluster(c, self.reps[c], self.sigma[c])
                self.redraw_event.wait(waittime)
                #ugly check to abort computation
                if self.abortNOW: return 0

            # if the update only the display we are finished
            if reps != None:
                return 0

            # -------- recompute pis -------
            self.pi = self.clustercenters / Numeric.sum(self.clustercenters)
            logger.info("Data distribution over clusters: "+str(self.pi))
            # -------- compute entropy -----
            entropy = Entropy(self.pi)
            logger.info("Entropy of data distribution over clusters = " + str(entropy))
            self.display.addEntropy(entropy)
            # -------- recompute reps -------
            for c in xrange(k):

                self.redraw_event.wait()
                #ugly check to abort computation
                if self.abortNOW: return 0
              
                new_rep = copy.copy([0]*self.dimensions)
                for i in xrange(self.nrSeqs):
                    new_rep += self.seqs[i] * self.data[i][c]

                if self.clustercenters[c] > 0:
                    self.reps[c] = new_rep * (1.0 / self.clustercenters[c])

            # -------- recompute sigmas -------
                    d = Numeric.array([0.0] * self.dimensions)
#                     logger.info(str(self.data[0][c])+" "+str(self.seqs[0])+" "+ str(self.reps[c]))
                    for i in xrange(self.nrSeqs):
                        d += self.data[i][c] * Numeric.power(self.seqs[i] - self.reps[c],2)
                    self.sigma[c] = Numeric.sqrt(d  / (self.dimensions * self.clustercenters[c]))
#                    logger.info("d: "+str(d)+ " sigma[c]: " + str(self.sigma[c]) +" "+ str(self.dimensions) +" "+ str(self.clustercenters))
                else:
                  logger.info("self.data["+str(c)+"] ! >0.")

            logger.info("Standard deviations:")
            for line in str(self.sigma).split("\n"): logger.info(line)

            return assignment_changed


    def findClosest (self, i):
        min_d = 99999.9
        d = Numeric.array([0.0] * self.k)
        result = -1
        for r in xrange(self.k):
            d[r] = self.distanceFunction(self.seqs[i], self.reps[r])
            if d[r] < min_d:
                min_d = d[r]
                result = r
        # scale the entropy using a cutoff value
        cutoff = 0.7
        scale_factor = 1.0 / (1.0 - cutoff)
        return (result, max(0.0, scale_factor * 
                            (Entropy(d / sum(d)) / self.entropyMax - cutoff) ))


    def computeResposibilities(self,i):
        result = Numeric.array([0.0] * self.k)
        sum = 0.0
        for r in xrange(self.k):
            d = math.exp(-self.beta * 
                         self.distanceFunction(self.seqs[i], self.reps[r]))
            result[r] = d
            sum += d

        try:
            result = result/sum
        except OverflowError:
            logger.error("Kaboum! Soft k-means algorithm just blew up!")
            logger.error("This happens especially in high-dimensional problems when individual data")
            logger.error("samples have a relatively high distance to all clusters in comparison with")
            logger.error("those lying closer to the clusters that have a higher responsibility.")
            logger.error("Kindly restart the algorithm or consider using hard k-means.")
            sys.exit(1)
        return (result,
                Numeric.argmax(result), 
                Entropy(result) / self.entropyMax)


    def computeGaussianResposibilities(self,i):
        result = Numeric.array([0.0] * self.k)
        sum = 0.0
        for r in xrange(len(self.reps)):
            #if the variance of a cluster is zero
            #it is only responsibility for the cluster center
            try:
                d = (self.pi[r] / Numeric.multiply.reduce(self.sqrtof2pi * self.sigma[r])) \
                    * math.exp(-1 * Numeric.add.reduce( Numeric.power(self.reps[r]-self.seqs[i], 2)
                                                        / (2*Numeric.power(self.sigma[r],2))))
            except:
                logger.warn("BAD. At least one cluster has zero variance.")
                logger.warn("You may choose a smaller number of clusters or")
                logger.warn("simply repeat the clustering and hope for better luck.")
                sys.exit(1)

            result[r] = d
            sum += d

        try:
            result = result/sum
        except OverflowError:
            logger.error("Kaboum! The mixture models algorithm just blew up!")
            logger.error("This happens especially in high-dimensional problems when individual data")
            logger.error("samples have a relatively high distance to all clusters in comparison with")
            logger.error("those lying closer to the clusters that have a higher responsibility.")
            logger.error("Kindly restart the algorithm or consider using hard k-means.")
            sys.exit(1)

        argmax = Numeric.argmax(result)
        #logger.info( "result: %s   argmax: %s" result, argmax)
        return (result,
                argmax,
                Entropy(result) / self.entropyMax)


    def matches(self,i,seq_ids):
        for j in seq_ids:
            if self.distanceFunction(self.seqs[i],self.seqs[j]) < eps:
                return True
        return False


    def selectkDistinctSeqs(self,k):
        """ Try to select k distinct sequences randomly.
            Return a list of their indices """

        seq_ids = range(self.nrSeqs) 
        result = []

        while len(result) < k and len(seq_ids) > 0:
            i = random.choice(seq_ids)
            if not self.matches(i,result):
                result.append(i)
            seq_ids.remove(i)
            
        return result


    def nrClusters(self):
        return len(self.clustercenters)



def sortByLen(x,y):
    if len(x) < len(y):
        return 1
    elif len(x) == len(y):
        return 0
    else:
        return -1


def stat(a):
    na = Numeric.array(a)
    return (MLab.mean(na), MLab.std(na), min(na), max(na))


def HammingDistanceStatistics(clustering, clusters):
    between_hds_list = [] # list of between cluster hamming distances
    within_hds_list = []  # list of all within cluster hamming distances for all clusters
    within_hds_stat = {}  # for each cluster this holds the within-variation stat()

    for i, ci in enumerate(clusters):
        for cj in clusters[i+1:]:
            for (s,t) in AllPairs(ci,cj):
                between_hds_list.append(HammingDistance(clustering.data[s], clustering.data[t]))

        hds_list = []
        if len(ci) > 2:
            for (s,t) in OrderedPairs(ci):
                h = HammingDistance(clustering.data[s], clustering.data[t])
                hds_list.append(h)
                within_hds_list.append(h)

            within_hds_stat[i] = stat(hds_list)
        else:
            within_hds_stat[i] = (None, None, None, None)

    return (stat(within_hds_list), stat(between_hds_list), within_hds_stat)
    

def comp_wdelta(within, between):
    return (between[0] - within[0]) / math.sqrt(between[1] + within[1])


def prettyPrint(ids, clustering):
    logger.info("# "+ str(clustering.nrClusters())+ " clusters of sizes")
    logger.info( string.join(map(str,Numeric.sort(map(len,clustering.clustercenters))),' '))

    # print all clusters by size
    clusters = copy.copy(clustering.clustercenters)
    clusters.sort(sortByLen)

    (within, between, within_hds_stat) = HammingDistanceStatistics(clustering, clusters)        

    wdelta = comp_wdelta(within, between)
    logger.info("# pair-wise hamming distances (weighted delta=%1.2f)" % wdelta)
    logger.info("#     between clusters avg=%1.2f (+/-%1.2f) min=%1.1f max=%1.1f" % between)
    logger.info("#      within clusters avg=%1.2f (+/-%1.2f) min=%1.1f max=%1.1f" % within)

    for i, cluster in enumerate(clusters):
        logger.info( "#----------------------------------------------------------------")
        logger.info("# cluster"+str( i + 1) + " size=%d" % len(cluster))

        if len(cluster) > 2:
            logger.info("#      within cluster avg=%1.2f (+/-%1.2f) min=%1.1f max=%1.1f" % \
                  within_hds_stat[i])

        #for s in cluster:
            #logger.info(str(ids[s]))
