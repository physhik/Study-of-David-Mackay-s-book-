from distutils.core import setup
setup(name='ClusterViz',
      version='0.2',
      description='Clustering visualization',
      long_description="""Performs a clustering algorithm and visualizes the process.
      Available algorithms are: hard k-means, soft k-means and mixture models.
      Visualization uses OpenGL. Data is presented in a simple one-sample-per-
      line format where the components are space separated.""",
      author='Jonas Maaskola',
      author_email='nayme@users.sourceforge.net',
      url='http://clusterviz.sourceforge.net/',
      license='GNU General Public License (GPL)',
      scripts=['scripts/clusterviz','scripts/generateSignals3D.py','scripts/generateSignals4D.py'],
      package_dir={'ClusterViz': ''},
      packages=['ClusterViz']
      )
