# -*- coding: iso8859_15 -*-
##/*
## *  Simple trackball-like motion adapted (ripped off) from projtex.c
## *  (written by David Yu and David Blythe).  See the SIGGRAPH '96
## *  Advanced OpenGL course notes.
## */


import math, sys, logging, os.path
from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

GLTB_TIME_EPSILON = 10

class trackball:

    def __init__(self):
        self.lasttime = 0
        self.lastposition = [0, 0, 0]

        self.zoomFactor = 1.0

        self.angle = 0.0
        self.axis = [0.0, 0.0, 0.0]

        self.width  = 0
        self.height = 0

        self.button = -1
        self.tracking = False
        self.animate = False

        self.center = [0,0,0] # the point we're looking at, the eye point is center+[0,0,-1]


    def _gltbPointToVector(self, x, y, width, height):
        "'project' x, y onto a hemi-sphere centered within width, height. "
        v = []
        v.append((2.0 * x - width) / width)
        v.append((height - 2.0 * y) / height)
        d = math.sqrt(v[0]**2 + v[1]**2)
        if d < 1.4:
            v.append(math.cos((math.pi / 2.0) * d))
        else:
            v.append(math.cos(math.pi / 2.0))
        a = 1.0 / math.sqrt(v[0]**2 + v[1]**2 + v[2]**2)
        return [a*x for x in v]

    def gltbStartMotion(self, x, y, button, time):

        assert(self.button != -1)

        self.tracking = True
        self.lasttime = time
        self.lastposition = self._gltbPointToVector(x, y, self.width, self.height)


    def gltbStopMotion(self, button, time):

        assert(self.button != -1)

        self.tracking = False

        self.animate = (time - self.lasttime < GLTB_TIME_EPSILON)


    def gltbAnimate(self):
        self.recalculateTransformationMatrix()
        glutPostRedisplay()


    def gltbInit(self, button):
        self.button = button
        self.angle = 0.0

        #/* put the identity in the trackball transform */
        glPushMatrix()
        glLoadIdentity()
        self.transform = glGetFloatv(GL_MODELVIEW_MATRIX)
        glPopMatrix()
        self.pan = self.transform
        
    def gltbMatrix(self):

        assert(self.button != -1)
        glTranslatef(*self.center)
        glMultMatrixf(self.transform)


    def gltbReshape(self, width, height):

        assert(self.button != -1)

        self.width  = width
        self.height = height


    def gltbMotion(self, x, y):
        
        assert(self.button != -1)
        if (self.tracking == False):
            return

        current_position = self._gltbPointToVector(x, y, self.width, self.height)

        ##  /* calculate the angle to rotate by (directly proportional to the
        ##     length of the mouse movement) */
        dx = current_position[0] - self.lastposition[0]
        dy = current_position[1] - self.lastposition[1]
        dz = current_position[2] - self.lastposition[2]
        self.angle = 90.0 * math.sqrt(dx**2 + dy**2 + dz**2)

        ##  /* calculate the axis of rotation (cross product) */
        self.axis[0] = self.lastposition[1] * current_position[2] - self.lastposition[2] * current_position[1]
        self.axis[1] = self.lastposition[2] * current_position[0] - self.lastposition[0] * current_position[2]
        self.axis[2] = self.lastposition[0] * current_position[1] - self.lastposition[1] * current_position[0]

        self.recalculateTransformationMatrix()
        ##  /* reset for next time */
        self.lasttime = glutGet(GLUT_ELAPSED_TIME)
        self.lastposition = current_position

    def recalculateTransformationMatrix(self):
        glPushMatrix()
        glLoadIdentity()
        glTranslatef(-self.center[0], -self.center[1], -self.center[2])
        glRotated(self.angle, self.axis[0], self.axis[1], self.axis[2])
        glTranslatef(*self.center)        
        glMultMatrixf(self.transform)
        self.transform = glGetFloatv(GL_MODELVIEW_MATRIX)
        glPopMatrix()

    def gltbZoom(self, x ,y, lastx, lasty):
        self.zoomFactor += (y - lasty)/1000.0
        if self.zoomFactor < 0.05:
            self.zoomFactor = 0.05; return
        elif self.zoomFactor > 3.0:
            self.zoomFactor = 3.0; return
        
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(45.0*self.zoomFactor,  self.width/self.height, 1.0, 100.0)
        glMatrixMode(GL_MODELVIEW)
        
    def gltbPan(self, x ,y, lastx, lasty):
        scale	  = 0.02 # XXX
        delta = [scale * (x - lastx), scale * (lasty- y), 0.0]
        self.center= [a+b for (a,b) in zip(delta, self.center)]
