#!/usr/bin/python
# Generate some data points

import sys
import random
from optparse import OptionParser

NDIMS = 4
defCenter = (0.0, 0.0, 0.0, 1.0)
usage = sys.argv[0]+""" nrSamples
Generate nrSamples """+str(NDIMS)+"""-dimensional signals from a number of weighted Gaussian distributions."""

if __name__ == "__main__":
  parser = OptionParser(usage)
  parser.add_option("-g", "--gauss", metavar="MU1 MU2 MU3 SDEV1 SDEV2 SDEV3 W", type="float", nargs=NDIMS*2+1, action="append",
    help="add a gaussion signal generator with parameter MU1 MU2 MU3 and SDEV1 SDEV2 SDEV3."
    "From this gaussian will be sampled using a weight of W.")

  (cloptions, args) = parser.parse_args()
#   print args, cloptions

  if len(args) < 1:
    print "Please provide the number of signals to be generated."
    sys.exit(1)

  if cloptions.gauss is None:
    print "Please give at least one gaussian signal generator."
    sys.exit(1)
	    
  if len (cloptions.gauss) == 0:
    cloptions.gauss = [defCenter]

  cnt = int(args[0])

  while (cnt > 0):
    sample = []
    cnt -= 1
    r = random.random()
#     print "r =",r
    select = 0
    while (r > 0):
      r -= cloptions.gauss[select][NDIMS*2]
#       print "r =",r
      select += 1
    select -= 1
#     print "select",select
    for i in range(NDIMS):
      sample.append(random.gauss(cloptions.gauss[select][i],cloptions.gauss[select][i+NDIMS]))
#       print cloptions.gauss[select]

    for term in sample:
      print term,
    print
