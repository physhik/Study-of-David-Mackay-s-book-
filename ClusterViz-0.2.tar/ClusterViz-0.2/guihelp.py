#
#    guihelp.py - GUI help text
#
#    Copyright (C) 2005  Jonas Maaskola
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

gui_help_text = """Visual kmeans clustering


This is a software to visualize the clustering process using the family of
kmeans algorithms.

The following commands are available in the GUI:

Commands
--------
h        Toggle display this help information
q / ESC  Quit program

f        Switch to fullscreen display
w        Switch to a windowed display

p        Pause the clustering thread
r        Restart the clustering thread

b        Go back one step in the clustering process history
n        Go forward one step in the clustering process history

j        Toggle the display of the trajectories
d        Toggle the display of the data
c        Toggle the display of the cluster represntations


Mouse control
-------------
LMB-click                       Rotate
MMB-click / Shift-LMB-click     Pan
RMB-click                       Zoom

Here LMB means left mouse button; MMB, RMB analogous."""
